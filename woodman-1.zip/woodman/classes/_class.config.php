﻿<?PHP
class config{

	public $HostDB = "localhost";
	public $UserDB = "root";
	public $PassDB = "";
	public $BaseDB = "localhost";
	public $BasePrefix = "evgesh"; //Префикс таблиц базы данных! Если не знаете что это такое то лучше не трогайте!
	public $FolderAdmin = "admin"; //Название папки админки! Будьте внимательны при изменении! Сначала измените название самой папки затем тут впишите ее название!
	public $SYSTEM_START_TIME = 1357338458;
	public $VAL = "Руб.";
	
	# PAYEER настройки
		public $AccountNumber = 'P10021365';
	public $apiId = '69535481';
	public $apiKey = '3mDuP7cqg4FjHv10';
	
	public $shopID = 69534774;
	public $secretW = "7OItnkgVFJ7ZGOTy";

	 # Настройки для оплаты кредита
        public $kredit_shopID = 1212;
	public $kredit_secretW = "SecretKEY";
	
	
	
}
?>