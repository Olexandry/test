<?PHP
$usid = $_SESSION["user_id"];

$db->Query("SELECT * FROM ".$pref."_users_b WHERE id = '$usid' LIMIT 1");
$user_data_first = $db->FetchArray();

$db->Query("SELECT * FROM ".$pref."_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();


	
		if($user_data_first["last_sbor"] < (time() - 50) ){
		
			$tomat_s = $func->SumCalc($sonfig_site["a_in_h"], $user_data_first["a_t"], $user_data_first["last_sbor"]);
			$straw_s = $func->SumCalc($sonfig_site["b_in_h"], $user_data_first["b_t"], $user_data_first["last_sbor"]);
			$pump_s = $func->SumCalc($sonfig_site["c_in_h"], $user_data_first["c_t"], $user_data_first["last_sbor"]);
			$peas_s = $func->SumCalc($sonfig_site["d_in_h"], $user_data_first["d_t"], $user_data_first["last_sbor"]);
			$pean_s = $func->SumCalc($sonfig_site["e_in_h"], $user_data_first["e_t"], $user_data_first["last_sbor"]);
			$pea_s = $func->SumCalc($sonfig_site["f_in_h"], $user_data_first["f_t"], $user_data_first["last_sbor"]);
			$pes_s = $func->SumCalc($sonfig_site["g_in_h"], $user_data_first["g_t"], $user_data_first["last_sbor"]);
			$db->Query("UPDATE ".$pref."_users_b SET 
			a_b = a_b + '$tomat_s', 
			b_b = b_b + '$straw_s', 
			c_b = c_b + '$pump_s', 
			d_b = d_b + '$peas_s', 
			e_b = e_b + '$pean_s',
			f_b = f_b + '$pea_s',
            g_b = g_b + '$pes_s',			
			all_time_a = all_time_a + '$tomat_s',
			all_time_b = all_time_b + '$straw_s',
			all_time_c = all_time_c + '$pump_s',
			all_time_d = all_time_d + '$peas_s',
			all_time_e = all_time_e + '$pean_s',
			all_time_f = all_time_f + '$pea_s',
			all_time_g = all_time_g + '$pes_s',
			last_sbor = '".time()."' 
			WHERE id = '$usid' LIMIT 1");
			

			
			$db->Query("SELECT * FROM ".$pref."_users_b WHERE id = '$usid' LIMIT 1");
			$user_data = $db->FetchArray();
			$all_items = $user_data["a_b"] + $user_data["b_b"] + $user_data["c_b"] + $user_data["d_b"] + $user_data["e_b"] + $user_data["f_b"] + $user_data["g_b"];
			
			if($all_items > 0){
	
			$money_add = $func->SellItems($all_items, $sonfig_site["items_per_coin"]);
		
			$tomat_b = $user_data["a_b"];
			$straw_b = $user_data["b_b"];
			$pump_b = $user_data["c_b"];
			$pean_b = $user_data["d_b"];
			$peas_b = $user_data["e_b"];
			$pea_b = $user_data["f_b"];
			$pes_b = $user_data["g_b"];
		
		$money_b = ( (100 - $sonfig_site["percent_sell"]) / 100) * $money_add;
		$money_p = ( ($sonfig_site["percent_sell"]) / 100) * $money_add;
		
		# ��������� ������
		$db->Query("UPDATE ".$pref."_users_b SET money_b = money_b + '$money_b', money_p = money_p + '$money_p', a_b = 0, b_b = 0, c_b = 0, d_b = 0, e_b = 0, f_b = 0, g_b = 0 
		WHERE id = '$usid'");
		
		$da = time();
		$dd = $da + 60*60*24*15;
		
		# ��������� ������ � ����������
		$db->Query("INSERT INTO ".$pref."_sell_items (user, user_id, a_s, b_s, c_s, d_s, e_s, f_s, g_s, amount, all_sell, date_add, date_del) VALUES 
		('$usname','$usid','$tomat_b','$straw_b','$pump_b','$pean_b','$peas_b','$pea_b','$pes_b','$money_add','$all_items','$da','$dd')");
		
	
		
		$db->Query("SELECT * FROM ".$pref."_users_b WHERE id = '$usid' LIMIT 1");
		$user_data = $db->FetchArray();
		
	}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			$db->Query("SELECT * FROM ".$pref."_users_b WHERE id = '$usid' LIMIT 1");
			$user_data = $db->FetchArray();
			
		}
?>
