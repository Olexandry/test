<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <title>Woodman</title>
  <link rel="stylesheet" href="views/default/css/style.css">
  <!-- Фавиконки -->
  <link rel="apple-touch-icon" sizes="180x180" href="views/default/img/favicons/apple-touch-icon.png">
  <link rel="icon" type="image/png" href="views/default/img/favicons/favicon-32x32.png" sizes="32x32">
  <link rel="icon" type="image/png" href="views/default/img/favicons/android-chrome-192x192.png" sizes="192x192">
  <link rel="icon" type="image/png" href="views/default/img/favicons/favicon-16x16.png" sizes="16x16">
  <link rel="manifest" href="views/default/img/favicons/manifest.json">
  <link rel="mask-icon" href="views/default/img/favicons/safari-pinned-tab.svg" color="#5bbad5">
  <link rel="shortcut icon" href="views/default/img/favicons/favicon.ico">
  <meta name="msapplication-TileColor" content="#3c2211">
  <meta name="msapplication-TileImage" content="views/default/img/favicons/mstile-144x144.png">
  <meta name="msapplication-config" content="views/default/img/favicons/browserconfig.xml">
  <meta name="theme-color" content="#ffffff">
  <!-- конец Фавиконки -->
</head>
<body>
<div id="handler"></div>
  <header class="header">
    <div class="wrap header__wrap">
      <div class="header__logo">
        <a href="/">
          <img class="header__img" src="views/default/img/logo.png" alt="logo">
        </a>
      </div>
    </div>
  </header>
  
  
  <main>
  
  
  <?PHP 
if($_SESSION["user"]) {?>
   <div class="wrap wrap__main" style="height: 2027px;">
      <aside class="aside">
                   <div class="login">
            <div class="login__input-wrap">
              <h6 class="login__name"><?=$_SESSION["user"]; ?></h6>

             

              <div class="login__balance">
                <div class="login__icon login__icon-rub"></div>
                <span class="login__val" id="rub">{!BALANCE_B!}</span>
              </div>
			  
			  
			  
			     <div class="login__balance">
                <div class="login__icon login__icon-rub"></div>
                <span class="login__val" id="rub">{!BALANCE_P!}</span>
              </div>
			  
			  
			  

			 
			  
            </div>
          </div>


		
          

          <ul class="aside__nav">
            <li class="aside__nav-item"><a class="aside__nav-link" href="/profile">Профиль</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/deposits">Лесорубы</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/fill">Пополнить баланс</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/payout">Вывести средства</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/bank">Банк</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/refsys">Партнерская программа</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/promo">Рекламные материалы</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/bonus">Ежедневный бонус</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/log">Лог событий</a></li>
            <li class="aside__nav-item"><a class="aside__nav-link" href="/logout">Выйти</a></li>
          </ul>
  
  
  
  
  
  
  <? } else { ?>	
  
  
  
    <div class="wrap wrap__main">
      <aside class="aside">
<?PHP
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM ".$pref."_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM ".$pref."_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

?>  
	  
<?PHP

	if(isset($_POST["log_email"])){
	
	$lmail = $func->IsMail($_POST["log_email"]);
	
		if($lmail !== false){
		
			$db->Query("SELECT id, user, pass, referer_id, banned FROM ".$pref."_users_a WHERE email = '$lmail'");
			if($db->NumRows() == 1){
			
			$log_data = $db->FetchArray();
			$pass = $func->md5Password($_POST["pass"]);
				if($log_data["pass"] == $pass){
				
					if($log_data["banned"] == 0){
						
						# Считаем рефералов
						$db->Query("SELECT COUNT(*) FROM ".$pref."_users_a WHERE referer_id = '".$log_data["id"]."'");
						$refs = $db->FetchRow();
						
						$db->Query("UPDATE ".$pref."_users_a SET referals = '$refs', date_login = '".time()."', ip = INET_ATON('".$func->UserIP."') WHERE id = '".$log_data["id"]."'");
						
						$_SESSION["user_id"] = $log_data["id"];
						$_SESSION["user"] = $log_data["user"];
						$_SESSION["referer_id"] = $log_data["referer_id"];
						Header("Location: /profile");
						
					}else echo "<div id='modal_alert' class='error' style='margin-top: -50px;'>Аккаунт заблокирован!!</div>";
				
				}else echo "
				
				
				
				<div id='modal_alert' class='error' style='margin-top: -50px;'>Пароль указан неверно!</div>
				
				
				
				";
			
			}else echo "
			
			<div id='modal_alert' class='error' style='margin-top: -50px;'>Указанный Email не зарегистрирован в системе!</div>
			";
			
		}else echo "
		<div id='modal_alert' class='error' style='margin-top: -50px;'>Email указан неверно!</div>
		";
	
	}

?>



<style>
#modal_alert{/*
			position:fixed;
			left:100%;
			top:100%;
			margin-top:10px;
			margin-left:-420px;
			z-index:10000;
			height:30px;
			width:400px;
			border-radius:10px;
			-webkit-border-radius:10px;
			-moz-border-radius:10px;
			o-border-radius:10px;
			padding:5px;*/
			
			
			background-color:#2e2e2e;
			color:#f5f5f5;
			width:700px;
			height:40px;
			line-height:40px;
			vertical-align:middle;
			position:fixed;
			left:100%;
			top:100%;
			margin-left:-710px;
			/*margin-top:-100px;*/
			font-weight:bold;
			/*padding:5px;*/
			text-align:center;
			z-index:10000;
			
			box-shadow:0px 0px 5px #000;
			
			
	}
	#success{
			box-shadow:inset 0px 0px 150px #0f0;
	}
	#error{
			box-shadow:inset 0px 0px 150px #f00;
	}
			
			</style>









	  
	  <form action="" method="post">
                <div class="login">
          <div class="login__input-wrap">
            <form class="login__form" id="login">
              <h5 class="login__headline">Авторизация</h5>
              <input class="input__text input__text-login" name="log_email" type="text" placeholder="Логин">
              <input class="input__text input__text-login" name="pass" type="password" placeholder="Пароль">
            </form>
          </div>    
        </div>

        
   


        <ul class="aside__nav">
          <li class="aside__nav-item"><a class="aside__nav-link" href="#" onclick="forms[0].submit();">Войти</a></li>
		  </form>
          <div id="error"></div>
		  <li class="aside__nav-item"><a class="aside__nav-link" href="/signup">Регистрация</a></li>
          <li class="aside__nav-item"><a class="aside__nav-link" href="/lost">Забыли пароль?</a></li>
        </ul>
		<?PHP } ?>
   <?PHP
$tfstats = time() - 60*60*24;
$db->Query("SELECT 
(SELECT COUNT(*) FROM ".$pref."_users_a) all_users,
(SELECT SUM(insert_sum) FROM ".$pref."_users_b) all_insert, 
(SELECT SUM(payment_sum) FROM ".$pref."_users_b) all_payment, 
(SELECT COUNT(*) FROM ".$pref."_users_a WHERE date_reg > '$tfstats') new_users");
$stats_data = $db->FetchArray();

?>

        <div class="stats">
          <h4 class="stats__headline">Статистика</h4>

          <ul class="stats__list">
            <li class="stats__item">
              <div class="stats__icon"></div>
              <h6 class="stats__name">Игроков:</h6>
			  
              <span class="stats__result"><?=$stats_data["all_users"]; ?></span>
            </li>
            <li class="stats__item">
              <div class="stats__icon"></div>
              <h6 class="stats__name">За 24 часа:</h6>
              <span class="stats__result"><?=$stats_data["new_users"]; ?></span>
            </li>
           
           
            <li class="stats__item">
              <div class="stats__icon"></div>
              <h6 class="stats__name">Пополнено:</h6>
              <span class="stats__result val__rub"><?=sprintf("%.2f",$stats_data["all_insert"]); ?></span>
            </li>
            <li class="stats__item">
              <div class="stats__icon"></div>
              <h6 class="stats__name">Выплачено:</h6>
              <span class="stats__result val__rub"><?=sprintf("%.2f",$stats_data["all_payment"]); ?></span>
            </li>
            <li class="stats__item">
              <div class="stats__icon"></div>
              <h6 class="stats__name">Игра живёт:</h6>
              <span class="stats__result"><?=intval(((time() - $config->SYSTEM_START_TIME) / 86400 ) +1); ?><span>-й день</span></span>
            </li>
          </ul>
          


        </div>
      </aside>

  
  

						
						<?PHP include("inc/_menu_top.php");
include("inc/_autostma.php"); 

						?>
												
				
        <div class="content">

				
						
							<?PHP include("inc/_menu_left.php"); ?>
							