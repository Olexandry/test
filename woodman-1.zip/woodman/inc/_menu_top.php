 <div class="container">
        <nav class="nav">
          <ul class="nav__list">
            <li class="nav__item">
              <a href="/">
                <div class="nav__icon"></div>
                <span class="nav__name">Главная</span>
              </a>
            </li>
            <li class="nav__item">
              <a href="/news">
                <div class="nav__icon"></div>
                <span class="nav__name">Новости</span>
              </a>
            </li>
            <li class="nav__item">
              <a href="/about">
                <div class="nav__icon"></div>
                <span class="nav__name">Об игре</span>
              </a>
            </li>
            <li class="nav__item">
              <a href="/contests">
                <div class="nav__icon"></div>
                <span class="nav__name">Конкурсы</span>
              </a>
            </li>
            <li class="nav__item">
              <a href="/stats">
                <div class="nav__icon"></div>
                <span class="nav__name">Статистика</span>
              </a>
            </li>
            <li class="nav__item">
              <a href="/rules">
                <div class="nav__icon"></div>
                <span class="nav__name">Правила</span>
              </a>
            </li>
            <li class="nav__item">
              <a href="/contact">
                <div class="nav__icon"></div>
                <span class="nav__name">Контакты</span>
              </a>
            </li>
          </ul>
        </nav>
