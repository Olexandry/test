</div>
      </div>
    </div>
    </div>
  </main>
  
  <footer class="wrap footer">
    <div class="footer__link">
      <a href="../https@payeer.com/" target="blank"><div class="footer__link-item"></div></a>
  
    </div>
  </footer>



    <script src="views/default/js/script.min.js"></script>
    
        <script src="views/default/js/jquery.cookie.js"></script>
    <script>
		var loc = new Date();
		var timezone = -loc.getTimezoneOffset();
		$.cookie('timezone', timezone);
	</script>
	</body>
</html>