-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 28 2017 г., 15:02
-- Версия сервера: 5.5.50
-- Версия PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `localhost`
--

-- --------------------------------------------------------

--
-- Структура таблицы `db_minilogus`
--

CREATE TABLE IF NOT EXISTS `db_minilogus` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `userlog` varchar(120) NOT NULL,
  `date_add` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_admin_log`
--

CREATE TABLE IF NOT EXISTS `evgesh_admin_log` (
  `id` int(1) NOT NULL,
  `username` varchar(55) NOT NULL,
  `passwordd` varchar(55) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `evgesh_admin_log`
--

INSERT INTO `evgesh_admin_log` (`id`, `username`, `passwordd`) VALUES
(1, 'EvgeSH', 'da50323ba6089e560b8b2cf446558ff6');

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_aukcion_game`
--

CREATE TABLE IF NOT EXISTS `evgesh_aukcion_game` (
  `id` int(11) NOT NULL,
  `user` varchar(150) NOT NULL,
  `date` int(11) NOT NULL,
  `timers` int(11) NOT NULL,
  `among` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_aukcion_game_stats`
--

CREATE TABLE IF NOT EXISTS `evgesh_aukcion_game_stats` (
  `id` int(11) NOT NULL,
  `user` varchar(150) NOT NULL,
  `date` int(11) NOT NULL,
  `among` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_bonus_list`
--

CREATE TABLE IF NOT EXISTS `evgesh_bonus_list` (
  `id` int(11) NOT NULL,
  `user` varchar(10) CHARACTER SET utf8 NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0',
  `win` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_bonus_list`
--

INSERT INTO `evgesh_bonus_list` (`id`, `user`, `user_id`, `sum`, `date_add`, `date_del`, `win`) VALUES
(5, 'admin', 1, 20, 1485206079, 1485292479, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_competition`
--

CREATE TABLE IF NOT EXISTS `evgesh_competition` (
  `id` int(11) NOT NULL,
  `1m` double NOT NULL DEFAULT '0',
  `2m` double NOT NULL DEFAULT '0',
  `3m` double NOT NULL DEFAULT '0',
  `user_1` varchar(10) NOT NULL,
  `user_2` varchar(10) NOT NULL,
  `user_3` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_end` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_competition_users`
--

CREATE TABLE IF NOT EXISTS `evgesh_competition_users` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_conabrul`
--

CREATE TABLE IF NOT EXISTS `evgesh_conabrul` (
  `id` int(11) NOT NULL,
  `rules` text NOT NULL,
  `about` text NOT NULL,
  `contacts` text NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_conabrul`
--

INSERT INTO `evgesh_conabrul` (`id`, `rules`, `about`, `contacts`) VALUES
(1, '<p>РџСЂРѕРІРµСЂРєР° РїСЂР°РІРёР»</p>', '<p>Рћ РїСЂРѕРµРєС‚Рµ</p>', '<p>РљРѕРЅС‚Р°РєС‚С‹ Р°РґРјРёРЅРёСЃС‚СЂР°С†РёРё</p>');

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_config`
--

CREATE TABLE IF NOT EXISTS `evgesh_config` (
  `id` int(11) NOT NULL,
  `min_pay` double NOT NULL DEFAULT '15',
  `ser_per_wmr` int(11) NOT NULL DEFAULT '1000',
  `ser_per_wmz` int(11) NOT NULL DEFAULT '3300',
  `ser_per_wme` int(11) NOT NULL DEFAULT '4200',
  `percent_swap` int(11) NOT NULL DEFAULT '0',
  `percent_sell` int(2) NOT NULL DEFAULT '10',
  `items_per_coin` int(11) NOT NULL DEFAULT '7',
  `a_in_h` int(11) NOT NULL DEFAULT '0',
  `b_in_h` int(11) NOT NULL DEFAULT '0',
  `c_in_h` int(11) NOT NULL DEFAULT '0',
  `d_in_h` int(11) NOT NULL DEFAULT '0',
  `e_in_h` int(11) NOT NULL DEFAULT '0',
  `f_in_h` int(11) NOT NULL DEFAULT '0',
  `g_in_h` int(11) NOT NULL DEFAULT '0',
  `amount_a_t` int(11) NOT NULL DEFAULT '0',
  `amount_b_t` int(11) NOT NULL DEFAULT '0',
  `amount_c_t` int(11) NOT NULL DEFAULT '0',
  `amount_d_t` int(11) NOT NULL DEFAULT '0',
  `amount_e_t` int(11) NOT NULL DEFAULT '0',
  `amount_f_t` int(11) NOT NULL DEFAULT '0',
  `amount_g_t` int(11) NOT NULL DEFAULT '0',
  `reg_key` int(1) NOT NULL DEFAULT '0',
  `auto` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_config`
--

INSERT INTO `evgesh_config` (`id`, `min_pay`, `ser_per_wmr`, `ser_per_wmz`, `ser_per_wme`, `percent_swap`, `percent_sell`, `items_per_coin`, `a_in_h`, `b_in_h`, `c_in_h`, `d_in_h`, `e_in_h`, `f_in_h`, `g_in_h`, `amount_a_t`, `amount_b_t`, `amount_c_t`, `amount_d_t`, `amount_e_t`, `amount_f_t`, `amount_g_t`, `reg_key`, `auto`) VALUES
(1, 20, 100, 3300, 4200, 50, 30, 10, 15, 52, 202, 825, 1950, 5625, 13750, 100, 250, 750, 2500, 5000, 12500, 25000, 2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_games_knb`
--

CREATE TABLE IF NOT EXISTS `evgesh_games_knb` (
  `id` int(11) NOT NULL,
  `summa` decimal(7,2) NOT NULL,
  `item` int(1) NOT NULL,
  `login` varchar(10) NOT NULL,
  `dat` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_insert_money`
--

CREATE TABLE IF NOT EXISTS `evgesh_insert_money` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `money` double NOT NULL DEFAULT '0',
  `serebro` int(11) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_lottery`
--

CREATE TABLE IF NOT EXISTS `evgesh_lottery` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_lottery_winners`
--

CREATE TABLE IF NOT EXISTS `evgesh_lottery_winners` (
  `id` int(11) NOT NULL,
  `user_a` varchar(10) NOT NULL,
  `bil_a` int(11) NOT NULL DEFAULT '0',
  `user_b` varchar(10) NOT NULL,
  `bil_b` int(11) NOT NULL DEFAULT '0',
  `user_c` varchar(10) NOT NULL,
  `bil_c` int(11) NOT NULL DEFAULT '0',
  `bank` float NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_minilogus`
--

CREATE TABLE IF NOT EXISTS `evgesh_minilogus` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `userlog` varchar(120) NOT NULL,
  `date_add` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `evgesh_minilogus`
--

INSERT INTO `evgesh_minilogus` (`id`, `user_id`, `userlog`, `date_add`) VALUES
(6, 2, 'Р’С‹ РЅР°РЅСЏР»Рё Р’РёРЅ Р·Р° 0 СЂСѓР±Р»РµР№', 1483738443),
(7, 2, 'Р’С‹ РЅР°РЅСЏР»Рё Р’РёРЅ Р·Р° 0 СЂСѓР±Р»РµР№', 1483738449),
(8, 2, 'Р’С‹ РЅР°РЅСЏР»Рё Р’РёРЅ Р·Р° 0 СЂСѓР±Р»РµР№', 1483738452),
(9, 2, 'Р’С‹ РЅР°РЅСЏР»Рё Р’РёРЅ Р·Р° 0 СЂСѓР±Р»РµР№', 1483738455),
(10, 2, 'Р’С‹ РЅР°РЅСЏР»Рё Р§РёРєРѕ Р·Р° 1001 СЂСѓР±Р»РµР№', 1483739066),
(11, 2, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 0 СЂСѓР±.', 1483739389),
(12, 2, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 0 СЂСѓР±.', 1483739583),
(13, 2, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 0 СЂСѓР±.', 1483739587),
(14, 2, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 100 СЂСѓР±.', 1483739610),
(15, 2, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 0 СЂСѓР±.', 1483739801),
(16, 2, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 100 СЂСѓР±.', 1483739805),
(17, 2, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 0 СЂСѓР±.', 1483739828),
(19, 1, 'Р’С‹ РЅР°РЅСЏР»Рё РЎРѕС‚РµСЂРѕ Р·Р° 250 СЂСѓР±Р»РµР№', 1483997445),
(20, 1, 'Р’С‹ РЅР°РЅСЏР»Рё РљР°Р»СЊРІРµСЂР° Р·Р° 5000 СЂСѓР±Р»РµР№', 1483997513),
(24, 1, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 100 СЂСѓР±.', 1485019640),
(26, 1, 'Р’С‹ РЅР°С‡Р°Р»Рё РѕРїРµСЂР°С†РёСЋ РїРѕРїРѕР»РЅРµРЅРёСЏ СЃС‡РµС‚Р° РЅР° СЃСѓРјРјСѓ 100 СЂСѓР±.', 1485603734);

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_news`
--

CREATE TABLE IF NOT EXISTS `evgesh_news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `news` text NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_payeer_insert`
--

CREATE TABLE IF NOT EXISTS `evgesh_payeer_insert` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_payeer_insert`
--

INSERT INTO `evgesh_payeer_insert` (`id`, `user_id`, `user`, `sum`, `date_add`, `status`) VALUES
(1, 2, 'demo', 0, 1483739389, 0),
(2, 2, 'demo', 0, 1483739583, 0),
(3, 2, 'demo', 0, 1483739587, 0),
(4, 2, 'demo', 100, 1483739610, 0),
(5, 2, 'demo', 0, 1483739801, 0),
(6, 2, 'demo', 100, 1483739805, 0),
(7, 2, 'demo', 0, 1483739828, 0),
(8, 2, 'demo', 110, 1483742492, 0),
(9, 2, 'demo', 110, 1483742580, 0),
(10, 2, 'demo', 110, 1483742584, 0),
(11, 1, 'admin', 100, 1485019640, 0),
(12, 1, 'admin', 100, 1485603734, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_payment`
--

CREATE TABLE IF NOT EXISTS `evgesh_payment` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `purse` varchar(20) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `comission` double NOT NULL DEFAULT '0',
  `valuta` varchar(3) NOT NULL DEFAULT 'RUB',
  `serebro` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `pay_sys` varchar(100) NOT NULL DEFAULT '0',
  `pay_sys_id` int(11) NOT NULL DEFAULT '0',
  `response` int(1) NOT NULL DEFAULT '0',
  `payment_id` int(11) NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_pin`
--

CREATE TABLE IF NOT EXISTS `evgesh_pin` (
  `id` int(11) NOT NULL,
  `pin` varchar(55) NOT NULL,
  `summa` double NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_pm`
--

CREATE TABLE IF NOT EXISTS `evgesh_pm` (
  `id` int(11) NOT NULL,
  `id_pm` int(11) NOT NULL,
  `user_id_in` int(11) NOT NULL,
  `login_in` varchar(55) NOT NULL,
  `user_id_out` int(11) NOT NULL,
  `login_out` varchar(55) NOT NULL,
  `theme` varchar(150) NOT NULL,
  `text` text NOT NULL,
  `status` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `inbox` int(11) NOT NULL,
  `outbox` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_pm_full`
--

CREATE TABLE IF NOT EXISTS `evgesh_pm_full` (
  `id` int(11) NOT NULL,
  `id_pm` int(11) NOT NULL,
  `user_id_in` int(11) NOT NULL,
  `login_in` varchar(55) NOT NULL,
  `text` text NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_recovery`
--

CREATE TABLE IF NOT EXISTS `evgesh_recovery` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `ip` int(10) unsigned NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_regkey`
--

CREATE TABLE IF NOT EXISTS `evgesh_regkey` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `referer_name` varchar(10) NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_sell_items`
--

CREATE TABLE IF NOT EXISTS `evgesh_sell_items` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `a_s` int(11) NOT NULL DEFAULT '0',
  `b_s` int(11) NOT NULL DEFAULT '0',
  `c_s` int(11) NOT NULL DEFAULT '0',
  `d_s` int(11) NOT NULL DEFAULT '0',
  `e_s` int(11) NOT NULL DEFAULT '0',
  `f_s` int(11) NOT NULL DEFAULT '0',
  `g_s` int(11) NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `all_sell` int(11) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=186 DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_sell_items`
--

INSERT INTO `evgesh_sell_items` (`id`, `user`, `user_id`, `a_s`, `b_s`, `c_s`, `d_s`, `e_s`, `f_s`, `g_s`, `amount`, `all_sell`, `date_add`, `date_del`) VALUES
(185, '', 1, 0, 6, 0, 0, 242, 0, 0, 24.8, 248, 1485604953, 1486900953),
(184, '', 1, 0, 1, 0, 0, 28, 0, 0, 2.9, 29, 1485604507, 1486900507),
(183, '', 1, 0, 1, 0, 0, 37, 0, 0, 3.8, 38, 1485604456, 1486900456),
(182, '', 1, 0, 6, 0, 0, 243, 0, 0, 24.9, 249, 1485604387, 1486900387),
(181, '', 1, 0, 1, 0, 0, 28, 0, 0, 2.9, 29, 1485603939, 1486899939),
(180, '', 1, 0, 1, 0, 0, 41, 0, 0, 4.2, 42, 1485603887, 1486899887),
(179, '', 1, 0, 1, 0, 0, 48, 0, 0, 4.9, 49, 1485603811, 1486899811),
(178, '', 1, 0, 4, 0, 0, 140, 0, 0, 14.4, 144, 1485603723, 1486899723),
(177, '', 1, 0, 1, 0, 0, 50, 0, 0, 5.1, 51, 1485603464, 1486899464),
(176, '', 1, 0, 4, 0, 0, 146, 0, 0, 15, 150, 1485603371, 1486899371),
(175, '', 1, 0, 11, 0, 0, 400, 0, 0, 41.1, 411, 1485603102, 1486899102),
(172, '', 1, 0, 25, 0, 0, 934, 0, 0, 95.9, 959, 1485602257, 1486898257),
(173, '', 1, 0, 1, 0, 0, 28, 0, 0, 2.9, 29, 1485602309, 1486898309),
(174, '', 1, 0, 1, 0, 0, 30, 0, 0, 3.1, 31, 1485602364, 1486898364);

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_sender`
--

CREATE TABLE IF NOT EXISTS `evgesh_sender` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mess` text NOT NULL,
  `page` int(5) NOT NULL DEFAULT '0',
  `sended` int(7) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_stats`
--

CREATE TABLE IF NOT EXISTS `evgesh_stats` (
  `id` int(11) NOT NULL,
  `all_users` int(11) NOT NULL DEFAULT '0',
  `all_payments` double NOT NULL DEFAULT '0',
  `all_insert` double NOT NULL DEFAULT '0',
  `donations` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_stats`
--

INSERT INTO `evgesh_stats` (`id`, `all_users`, `all_payments`, `all_insert`, `donations`) VALUES
(2, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_stats_btree`
--

CREATE TABLE IF NOT EXISTS `evgesh_stats_btree` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `user` varchar(10) NOT NULL,
  `tree_name` varchar(10) NOT NULL,
  `amount` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_stats_fortuna`
--

CREATE TABLE IF NOT EXISTS `evgesh_stats_fortuna` (
  `id` int(11) NOT NULL,
  `login` varchar(55) NOT NULL,
  `sum` varchar(55) NOT NULL,
  `date` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_stats_knb`
--

CREATE TABLE IF NOT EXISTS `evgesh_stats_knb` (
  `id` int(13) NOT NULL,
  `summa` double NOT NULL,
  `login` varchar(55) NOT NULL,
  `usid` int(13) NOT NULL,
  `item` int(1) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_swap_ser`
--

CREATE TABLE IF NOT EXISTS `evgesh_swap_ser` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `amount_b` double NOT NULL DEFAULT '0',
  `amount_p` double NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_del` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_ticket_full`
--

CREATE TABLE IF NOT EXISTS `evgesh_ticket_full` (
  `id` int(11) NOT NULL,
  `id_ticket` int(11) NOT NULL,
  `login` varchar(55) NOT NULL,
  `text` text NOT NULL,
  `date` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_ticket_id`
--

CREATE TABLE IF NOT EXISTS `evgesh_ticket_id` (
  `id` int(13) NOT NULL,
  `user_id` int(13) NOT NULL,
  `login` varchar(55) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `read` int(11) NOT NULL,
  `admin_read` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_users_a`
--

CREATE TABLE IF NOT EXISTS `evgesh_users_a` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL,
  `referer` varchar(10) NOT NULL,
  `referer_id` int(11) NOT NULL DEFAULT '0',
  `referals` int(11) NOT NULL DEFAULT '0',
  `date_reg` int(11) NOT NULL DEFAULT '0',
  `date_login` int(11) NOT NULL DEFAULT '0',
  `ip` int(10) unsigned NOT NULL DEFAULT '0',
  `banned` int(1) NOT NULL DEFAULT '0',
  `chat_moder` int(1) NOT NULL,
  `rating` double NOT NULL,
  `ava` varchar(55) NOT NULL,
  `name` varchar(25) NOT NULL,
  `pol` int(1) NOT NULL,
  `purse` varchar(12) NOT NULL DEFAULT 'не задан'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_users_a`
--

INSERT INTO `evgesh_users_a` (`id`, `user`, `email`, `pass`, `referer`, `referer_id`, `referals`, `date_reg`, `date_login`, `ip`, `banned`, `chat_moder`, `rating`, `ava`, `name`, `pol`, `purse`) VALUES
(1, 'admin', 'admin@admin.ru', 'da50323ba6089e560b8b2cf446558ff6', '', 1, 2, 1483731555, 1485604953, 2130706433, 0, 0, 0, '', '', 0, 'не задан'),
(2, 'demo', 'demo@demo.ru', 'da50323ba6089e560b8b2cf446558ff6', 'admin', 1, 0, 1483736357, 1483738246, 2130706433, 0, 0, 0, '', '', 0, 'не задан');

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_users_b`
--

CREATE TABLE IF NOT EXISTS `evgesh_users_b` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `money_b` double NOT NULL DEFAULT '0',
  `money_p` double NOT NULL DEFAULT '0',
  `a_t` int(11) NOT NULL DEFAULT '0',
  `b_t` int(11) NOT NULL DEFAULT '0',
  `c_t` int(11) NOT NULL DEFAULT '0',
  `d_t` int(11) NOT NULL DEFAULT '0',
  `e_t` int(11) NOT NULL DEFAULT '0',
  `f_t` int(11) NOT NULL DEFAULT '0',
  `g_t` int(11) NOT NULL DEFAULT '0',
  `a_b` int(11) NOT NULL DEFAULT '0',
  `b_b` int(11) NOT NULL DEFAULT '0',
  `c_b` int(11) NOT NULL DEFAULT '0',
  `d_b` int(11) NOT NULL DEFAULT '0',
  `e_b` int(11) NOT NULL DEFAULT '0',
  `f_b` int(11) NOT NULL DEFAULT '0',
  `g_b` int(11) NOT NULL DEFAULT '0',
  `all_time_a` int(11) NOT NULL DEFAULT '0',
  `all_time_b` int(11) NOT NULL DEFAULT '0',
  `all_time_c` int(11) NOT NULL DEFAULT '0',
  `all_time_d` int(11) NOT NULL DEFAULT '0',
  `all_time_e` int(11) NOT NULL DEFAULT '0',
  `all_time_f` int(11) NOT NULL DEFAULT '0',
  `all_time_g` int(11) NOT NULL DEFAULT '0',
  `last_sbor` int(11) NOT NULL DEFAULT '0',
  `from_referals` double NOT NULL DEFAULT '0',
  `to_referer` double NOT NULL DEFAULT '0',
  `payment_sum` double NOT NULL DEFAULT '0',
  `insert_sum` double NOT NULL DEFAULT '0',
  `billet` int(10) NOT NULL,
  `kredit` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `evgesh_users_b`
--

INSERT INTO `evgesh_users_b` (`id`, `user`, `money_b`, `money_p`, `a_t`, `b_t`, `c_t`, `d_t`, `e_t`, `f_t`, `g_t`, `a_b`, `b_b`, `c_b`, `d_b`, `e_b`, `f_b`, `g_b`, `all_time_a`, `all_time_b`, `all_time_c`, `all_time_d`, `all_time_e`, `all_time_f`, `all_time_g`, `last_sbor`, `from_referals`, `to_referer`, `payment_sum`, `insert_sum`, `billet`, `kredit`) VALUES
(1, 'admin', 62700.15999999995, 26824.440000000013, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 23226, 0, 0, 870710, 0, 0, 1485604953, 0, 0, 0, 0, 0, 0),
(2, 'demo', 80000, 0, 1, 0, 0, 0, 0, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1483738443, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_views_reflink`
--

CREATE TABLE IF NOT EXISTS `evgesh_views_reflink` (
  `id_view` int(11) NOT NULL,
  `id_ref` int(11) NOT NULL,
  `ip_view` varchar(16) NOT NULL,
  `date_view` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `evgesh_wall`
--

CREATE TABLE IF NOT EXISTS `evgesh_wall` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login` varchar(55) NOT NULL,
  `date` int(11) NOT NULL,
  `type` int(1) NOT NULL,
  `text` text NOT NULL,
  `ava` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `wmrush_chat`
--

CREATE TABLE IF NOT EXISTS `wmrush_chat` (
  `id` int(11) NOT NULL,
  `to` varchar(10) NOT NULL,
  `user` char(10) NOT NULL,
  `comment` varchar(255) CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL,
  `time` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `wmrush_chat_ban`
--

CREATE TABLE IF NOT EXISTS `wmrush_chat_ban` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `time_uban` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `db_minilogus`
--
ALTER TABLE `db_minilogus`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_admin_log`
--
ALTER TABLE `evgesh_admin_log`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_aukcion_game`
--
ALTER TABLE `evgesh_aukcion_game`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_aukcion_game_stats`
--
ALTER TABLE `evgesh_aukcion_game_stats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_bonus_list`
--
ALTER TABLE `evgesh_bonus_list`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_competition`
--
ALTER TABLE `evgesh_competition`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_competition_users`
--
ALTER TABLE `evgesh_competition_users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_conabrul`
--
ALTER TABLE `evgesh_conabrul`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_config`
--
ALTER TABLE `evgesh_config`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_games_knb`
--
ALTER TABLE `evgesh_games_knb`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_insert_money`
--
ALTER TABLE `evgesh_insert_money`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_lottery`
--
ALTER TABLE `evgesh_lottery`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_lottery_winners`
--
ALTER TABLE `evgesh_lottery_winners`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_minilogus`
--
ALTER TABLE `evgesh_minilogus`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_news`
--
ALTER TABLE `evgesh_news`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_payeer_insert`
--
ALTER TABLE `evgesh_payeer_insert`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_payment`
--
ALTER TABLE `evgesh_payment`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_pin`
--
ALTER TABLE `evgesh_pin`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_pm`
--
ALTER TABLE `evgesh_pm`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_pm_full`
--
ALTER TABLE `evgesh_pm_full`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_recovery`
--
ALTER TABLE `evgesh_recovery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ip` (`ip`);

--
-- Индексы таблицы `evgesh_regkey`
--
ALTER TABLE `evgesh_regkey`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `evgesh_sell_items`
--
ALTER TABLE `evgesh_sell_items`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_sender`
--
ALTER TABLE `evgesh_sender`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_stats`
--
ALTER TABLE `evgesh_stats`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_stats_btree`
--
ALTER TABLE `evgesh_stats_btree`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_stats_fortuna`
--
ALTER TABLE `evgesh_stats_fortuna`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_stats_knb`
--
ALTER TABLE `evgesh_stats_knb`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_swap_ser`
--
ALTER TABLE `evgesh_swap_ser`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_ticket_full`
--
ALTER TABLE `evgesh_ticket_full`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_ticket_id`
--
ALTER TABLE `evgesh_ticket_id`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_users_a`
--
ALTER TABLE `evgesh_users_a`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `ip` (`ip`);

--
-- Индексы таблицы `evgesh_users_b`
--
ALTER TABLE `evgesh_users_b`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `evgesh_wall`
--
ALTER TABLE `evgesh_wall`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `wmrush_chat`
--
ALTER TABLE `wmrush_chat`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `wmrush_chat_ban`
--
ALTER TABLE `wmrush_chat_ban`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `db_minilogus`
--
ALTER TABLE `db_minilogus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_admin_log`
--
ALTER TABLE `evgesh_admin_log`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `evgesh_aukcion_game`
--
ALTER TABLE `evgesh_aukcion_game`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_aukcion_game_stats`
--
ALTER TABLE `evgesh_aukcion_game_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_bonus_list`
--
ALTER TABLE `evgesh_bonus_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT для таблицы `evgesh_competition`
--
ALTER TABLE `evgesh_competition`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `evgesh_competition_users`
--
ALTER TABLE `evgesh_competition_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_conabrul`
--
ALTER TABLE `evgesh_conabrul`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `evgesh_config`
--
ALTER TABLE `evgesh_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `evgesh_games_knb`
--
ALTER TABLE `evgesh_games_knb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_insert_money`
--
ALTER TABLE `evgesh_insert_money`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT для таблицы `evgesh_lottery`
--
ALTER TABLE `evgesh_lottery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_lottery_winners`
--
ALTER TABLE `evgesh_lottery_winners`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_minilogus`
--
ALTER TABLE `evgesh_minilogus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT для таблицы `evgesh_news`
--
ALTER TABLE `evgesh_news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_payeer_insert`
--
ALTER TABLE `evgesh_payeer_insert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `evgesh_payment`
--
ALTER TABLE `evgesh_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_pin`
--
ALTER TABLE `evgesh_pin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_pm`
--
ALTER TABLE `evgesh_pm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_pm_full`
--
ALTER TABLE `evgesh_pm_full`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_recovery`
--
ALTER TABLE `evgesh_recovery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_regkey`
--
ALTER TABLE `evgesh_regkey`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_sell_items`
--
ALTER TABLE `evgesh_sell_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=186;
--
-- AUTO_INCREMENT для таблицы `evgesh_sender`
--
ALTER TABLE `evgesh_sender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_stats`
--
ALTER TABLE `evgesh_stats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `evgesh_stats_btree`
--
ALTER TABLE `evgesh_stats_btree`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT для таблицы `evgesh_stats_fortuna`
--
ALTER TABLE `evgesh_stats_fortuna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_stats_knb`
--
ALTER TABLE `evgesh_stats_knb`
  MODIFY `id` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_swap_ser`
--
ALTER TABLE `evgesh_swap_ser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_ticket_full`
--
ALTER TABLE `evgesh_ticket_full`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_ticket_id`
--
ALTER TABLE `evgesh_ticket_id`
  MODIFY `id` int(13) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `evgesh_users_a`
--
ALTER TABLE `evgesh_users_a`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `evgesh_wall`
--
ALTER TABLE `evgesh_wall`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wmrush_chat`
--
ALTER TABLE `wmrush_chat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `wmrush_chat_ban`
--
ALTER TABLE `wmrush_chat_ban`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
