<div class="content">
        <div class="header">
      

            <h1 class="page-title">История покупок кирок</h1>
                    

        </div>
        <div class="main-content">
		
		
   
        <div class="panel panel-default">
         <center>
       
		
<?PHP
/* 
Script MINE-INCOME
Autor: EvgeSH
URL: MyShopScript.ru
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$tdadd = time() - 5*60;
	if(isset($_POST["clean"])){
	
		$db->Query("DELETE FROM ".$pref."_stats_btree WHERE date_add < '$tdadd'");
		echo "<center><font color = 'green'><b>Очищено</b></font></center><BR />";
	}

$db->Query("SELECT * FROM ".$pref."_stats_btree ORDER BY id DESC");

if($db->NumRows() > 0){

?>
<table class="table table-bordered table-striped" >
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Логин</th>
                  <th>Ракета</th>
				   <th>Стоимость</th>
				    <th>Дата</th>
                </tr>
              </thead>



<?PHP

	while($data = $db->FetchArray()){
	
	?>
	
	<tbody>
                <tr>
                  <td><?=$data["id"]; ?></td>
                  <td><?=$data["user"]; ?></td>
                  <td><?=$data["tree_name"]; ?></td>
                <td><?=$data["amount"]; ?></td>
                  <td><?=date("d.m.Y в H:i:s",$data["date_add"]); ?></td>
				
				</tr>
                
              </tbody>
	
	

	<?PHP
	
	}

?>

</table>

<form action="" method="post">
<center><input type="submit" name="clean" class="form-controlspan12 form-control" value="Очистить" /></center>
</form>
<?PHP

}else echo "<center><b>Записей нет</b></center><BR />";
?>


     
        </div>
    </div>
    
   


  <footer>
                <hr>

                
                <p class="pull-right">Admin <a href="https://myshopscript.ru" target="_blank">Panel</a> by <a href="https://myshopscript.ru" target="_blank">EvgeSH</a></p>
                <p>© 2016 <a href="https://myshopscript.ru" target="_blank">EvgeSH</a></p>
            </footer>	