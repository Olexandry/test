    <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
          <a class="" href="index.html"><span class="navbar-brand"><span class="fa fa-paper-plane"></span> Панель администратора</span></a></div>

        <div class="navbar-collapse collapse" style="height: 1px;">

        </div>
      </div>
    </div>
	
	<div class="dialog">
    <div class="panel panel-default">
        <p class="panel-heading no-collapse">Авторизация</p>
        <div class="panel-body">
            


<?PHP
/* 
Script MINE-INCOME
Autor: EvgeSH
URL: MyShopScript.ru
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
if(isset($_SESSION["admin"])){ Header("Location: /".$admFolder.""); return; }

if(isset($_POST["admlogin"])){

	$db->Query("SELECT * FROM ".$pref."_admin_log WHERE id = 1 LIMIT 1");
	$data_log = $db->FetchArray();
	$pass = $_POST["admpass"];
	$pass = $func->md5Password($pass);
	$login = $db->RealEscape($_POST['admlogin']);
	
	if(strtolower($login) == strtolower($data_log["username"]) AND strtolower($pass) == strtolower($data_log["passwordd"]) ){
	
		$_SESSION["admin"] = true;
		Header("Location: /".$admFolder."");
		return;
	}else echo "<center><font color = 'red'><b>Неверно введен логин и/или пароль</b></font></center><BR />";
	
}

?>

<form action="" method="post">
                <div class="form-group">
                    <label>Логин:</label>
                    <input type="text" name="admlogin"  class="form-control span12" value="" />
                </div>
                <div class="form-group">
                <label>Пароль:</label>
                   <input type="password" name="admpass" class="form-controlspan12 form-control" value="" />
                </div>
                <input type="submit" value="Войти" />
            
                <div class="clearfix"></div>
            </form>
        </div>
    </div>
    <p class="pull-right" style=""><a href="https://myshopscript.ru" target="blank" style="font-size: .75em; margin-top: .25em;">Design by EvgeSH</a></p>
  
</div>

