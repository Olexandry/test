

<?PHP if(!isset($_GET["menu"]) OR $_GET["menu"] != "admin4ik"){ ?>

<?PHP } ?>
								
				<script src="lib/bootstrap/js/bootstrap.js"></script>
    <script type="text/javascript">
        $("[rel=tooltip]").tooltip();
        $(function() {
            $('.demo-cancel-click').click(function(){return false;});
        });
    </script>
    
  
</body></html>
