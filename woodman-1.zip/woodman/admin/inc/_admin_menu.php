   <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
        
          <a class="" href="index.html"><span class="navbar-brand"><span class="fa fa-paper-plane"></span> Панель администратора</span></a></div>

        <div class="navbar-collapse collapse" style="height: 1px;">
          <ul id="main-menu" class="nav navbar-nav navbar-right">
            <li class="dropdown hidden-xs">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <span class="glyphicon glyphicon-user padding-right-small" style="position:relative;top: 3px;"></span> Привет, EvgeSH
                    <i class="fa fa-caret-down"></i>
                </a>

              <ul class="dropdown-menu">
                <li class="divider"></li>
                <li><a tabindex="-1" href="index.php?menu=exit">Выход</a></li>
              </ul>
            </li>
          </ul>

        </div>
      </div>

	  
	  <div class="sidebar-nav">
    <ul>
    <li><a href="#" data-target=".dashboard-menu" class="nav-header" data-toggle="collapse"><i class="fa fa-fw fa-dashboard"></i> Статистика проекта<i class="fa fa-collapse"></i></a></li>
    <li><ul class="dashboard-menu nav nav-list collapse in">
            <li><a href="index.php?menu=stats"><span class="fa fa-caret-right"></span> Статистика общая</a></li>
            <li ><a href="index.php?menu=story_buy"><span class="fa fa-caret-right"></span> История покупок</a></li>
            <li ><a href="index.php?menu=story_swap"><span class="fa fa-caret-right"></span> История обменов</a></li>
            <li ><a href="index.php?menu=story_insert"><span class="fa fa-caret-right"></span> История пополнений</a></li>
			<li ><a href="index.php?menu=payments"><span class="fa fa-caret-right"></span> История выплат</a></li>
            <li ><a href="index.php?menu=story_sell"><span class="fa fa-caret-right"></span> История продаж</a></li>
			
    </ul></li>

    <li><a href="#" data-target=".premium-menu" class="nav-header collapsed" data-toggle="collapse"><i class="fa fa-fw fa-fighter-jet"></i> Настройки проекта<i class="fa fa-collapse"></i></a></li>
        <li><ul class="premium-menu nav nav-list collapse">
              
            <li ><a href="index.php?menu=config"><span class="fa fa-caret-right"></span> Технические настройки</a></li>
            <li ><a href="index.php?menu=news"><span class="fa fa-caret-right"></span> Новости</a></li>
            <li ><a href="index.php?menu=compconfig"><span class="fa fa-caret-right"></span> Конкурс рефералов</a></li>
          
          
    </ul></li>

        

       

        <li><a href="index.php?menu=users" class="nav-header"><i class="fa fa-fw fa-question-circle"></i> Список пользователей</a></li>
            <li><a href="index.php?menu=sender" class="nav-header"><i class="fa fa-fw fa-comment"></i> Массовая рассылка</a></li>
              
            </ul>
    </div>
	  
	  
	  
	  
	  
	  
	 
	
	
	
