<?PHP
######################################
# Скрипт Fruit Farm
# Автор Rufus
# ICQ: 819-374
# Skype: Rufus272
######################################
$_OPTIMIZATION["title"] = "Восстановление пароля";
$_OPTIMIZATION["description"] = "Восстановление забытого пароля";
$_OPTIMIZATION["keywords"] = "Восстановление забытого пароля";

if(isset($_SESSION["user_id"])){ Header("Location: /account"); return; }

?>

<?PHP

	if(isset($_POST["email"])){

		
		
		$email = $func->IsMail($_POST["email"]);
		$time = time();
		$tdel = $time + 60*15;
		
			if($email !== false){
				
				$db->Query("DELETE FROM ".$pref."_recovery WHERE date_del < '$time'");
				$db->Query("SELECT COUNT(*) FROM ".$pref."_recovery WHERE ip = INET_ATON('".$func->UserIP."') OR email = '$email'");
				if($db->FetchRow() == 0){
				
					$db->Query("SELECT id, user, email, pass FROM ".$pref."_users_a WHERE email = '$email'");
					if($db->NumRows() == 1){
					$db_q = $db->FetchArray();
					$rn = rand(515165115, 999999999999);
					$new_pass = $func->md5Password($rn);
					
					# Вносим запись в БД
					$db->Query("INSERT INTO ".$pref."_recovery (email, ip, date_add, date_del) VALUES ('$email',INET_ATON('".$func->UserIP."'),'$time','$tdel')");
					$db->Query("UPDATE ".$pref."_users_a SET pass = '$new_pass' WHERE email = '".$db_q["email"]."'");
					# Отправляем пароль
					$sender = new isender;
					$sender -> RecoveryPassword($db_q["email"], $rn, $db_q["email"]);
					
					echo "<center><font color = 'green'><b>Данные для входа отправлены на Email</b></font></center>";
					?>
					
					<?PHP
					return; 
					
					}else echo "<center><font color = 'red'><b>Пользователь с таким Email не зарегистрирован</b></font></center>";
				
				}else echo "<center><font color = 'red'><b>На Ваш Email или IP уже был отправлен пароль за последние 15 минут</b></font></center>";
				
			}else echo "<center><font color = 'red'><b>Email указан неверно</b></font></center>";
		
		
	
	}

?>


<form class="lost" method="post" accept-charset="utf-8" onsubmit="return false;" id="lost">
	<input type="text" class="input__text input__text-lost" placeholder="E-mail" name="user_email" value="<?=(isset($_POST["email"])) ? $_POST["email"] : false; ?>">
	<div id="lost_error"></div>
	<input type="button" class="input__btn" value="Восстановить" name="submit" onclick="forms[0].submit();">
</form>   

