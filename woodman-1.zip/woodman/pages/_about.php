<?PHP
######################################
# Скрипт Fruit Farm
# Автор Rufus
# ICQ: 819-374
# Skype: Rufus272
######################################
$_OPTIMIZATION["title"] = "О проекте";
$_OPTIMIZATION["description"] = "О нашем проекте";
$_OPTIMIZATION["keywords"] = "Немного о нас и о нашем проекте";
?>
<div class="about">
    <h3 class="about__headline">Игровой процесс</h3>
    <p class="about__text">Пригласи на работу, нажатием на кнопку 'Нанять', любого, понравившегося, тебе дровосека. И начни развивать своё дереводобывающее предприятие.  Только учти, что каждый работяга имеет свою цену. Если он отказывается на тебя работать, значит денег на балансе у тебя не достаточно, для оплаты его услуг, и нужно свой счёт пополнить, с удобной для тебя платежной системы или взять кредит в игровом банке. Ну или пойти другим путем. Нанять менее, привлекательного, для тебя дровосека, и получать доход от его работы.  Выбор только за тобой. 
<p>Крутых мужиков проекта Wood Man нанимать можно в любом количестве с любой скоростью.</p>
<p>После того, как дровосек нарубит необходимое количество дров, ты можешь их продать. А на вырученные деньги нанять еще несколько крутых мужиков проекта. Или вывести деньги на свой кошелек.</p></p>
    <p class="about__text">Ввод и вывод средств</p>
    <p class="about__text">Все наши супер дровосеки предоставляют качественные услуги за деньги (вообщем как и везде) и для удобства участников проекта нанять их можно за разную валюту и разными способами. В игре реализована возможность пополнять баланс в проекте с трех крупнейших платежных систем : Payeer, Perfect Money и AdvCASH.</p>
    <h3 class="about__headline">Реферальная программа</h3>
    <p class="about__text">Бизнес выгодней и интересней вести с компаньонами и друзьями. Поэтому приглашай друзей по своей реферальной ссылке и развивайте вместе своё огромное дереводобывающее предприятие. Стандартная реферальная программа : 7%. Для представителей блогов, мониторингов и других ресурсов реферальная программа : 12%, при условии, что представитель сделает вклад в проект от 100$ или 5 000 руб. и будет осуществлять поддержку и консультацию инвесторов.</p>
    <h3 class="about__headline">Маркетинг</h3>

    <div class="divider"></div>
</div>
<div class="feature__item ">
    <img src="views/default/img/store-item-1.png" class="feature__img" alt="feature-item">
    <div class="feature__table">
        <table class="table table-feature">
            <tbody><tr class="table__data">
                <td>Имя лесоруба : <span class="table__login">Чико</span></td>
            </tr>
            <tr class="table__data">
                <td>Скорость добычи в месяц :
                   
									<span class="table__goods-rub">15</span>
					<span class="grey"> (15%)</span>
                </td>
            </tr>
            <tr class="table__data">
              <td>Стоимость :
               
				               <span class="table__goods-rub">100</span>
              </td>
            </tr>
            <tr class="table__data">
              <td>
                <a href="signup" class="input__btn input__btn-about">Нанять</a>
              </td>
            </tr>
        </tbody></table>
    </div>
</div>
<div class="feature__item ">
    <img src="views/default/img/store-item-2.png" class="feature__img" alt="feature-item">
    <div class="feature__table">
        <table class="table table-feature">
            <tbody><tr class="table__data">
                <td>Имя лесоруба : <span class="table__login">Сотеро</span></td>
            </tr>
            <tr class="table__data">
                <td>Скорость добычи в месяц :
                  	<span class="table__goods-rub">52,5</span>
					<span class="grey"> (21%)</span>
                </td>
            </tr>
            <tr class="table__data">
              <td>Стоимость :
                <span class="table__goods-rub">250</span>
              </td>
            </tr>
            <tr class="table__data">
              <td>
                <a href="signup" class="input__btn input__btn-about">Нанять</a>
              </td>
            </tr>
        </tbody></table>
    </div>
</div>
<div class="feature__item ">
    <img src="views/default/img/store-item-3.png" class="feature__img" alt="feature-item">
    <div class="feature__table">
        <table class="table table-feature">
            <tbody><tr class="table__data">
                <td>Имя лесоруба : <span class="table__login">О'Рейли</span></td>
            </tr>
            <tr class="table__data">
                <td>Скорость добычи в месяц :
                   		<span class="table__goods-rub">202,5</span>
					<span class="grey"> (27%)</span>
                </td>
            </tr>
            <tr class="table__data">
              <td>Стоимость :
                  <span class="table__goods-rub">750</span>
              </td>
            </tr>
            <tr class="table__data">
              <td>
                <a href="signup" class="input__btn input__btn-about">Нанять</a>
              </td>
            </tr>
        </tbody></table>
    </div>
</div>
<div class="feature__item ">
    <img src="views/default/img/store-item-4.png" class="feature__img" alt="feature-item">
    <div class="feature__table">
        <table class="table table-feature">
            <tbody><tr class="table__data">
                <td>Имя лесоруба : <span class="table__login">Бритт</span></td>
            </tr>
            <tr class="table__data">
                <td>Скорость добычи в месяц :
                   	<span class="table__goods-rub">825</span>
					<span class="grey"> (33%)</span>
                </td>
            </tr>
            <tr class="table__data">
              <td>Стоимость :
                    <span class="table__goods-rub">2 500</span>
              </td>
            </tr>
            <tr class="table__data">
              <td>
                <a href="signup" class="input__btn input__btn-about">Нанять</a>
              </td>
            </tr>
        </tbody></table>
    </div>
</div>
<div class="feature__item ">
    <img src="views/default/img/store-item-5.png" class="feature__img" alt="feature-item">
    <div class="feature__table">
        <table class="table table-feature">
            <tbody><tr class="table__data">
                <td>Имя лесоруба : <span class="table__login">Кальвера</span></td>
            </tr>
            <tr class="table__data">
                <td>Скорость добычи в месяц :
                   	<span class="table__goods-rub">1 950</span>
					<span class="grey"> (39%)</span>
                </td>
            </tr>
            <tr class="table__data">
              <td>Стоимость :
                        <span class="table__goods-rub">5 000</span>
              </td>
            </tr>
            <tr class="table__data">
              <td>
                <a href="signup" class="input__btn input__btn-about">Нанять</a>
              </td>
            </tr>
        </tbody></table>
    </div>
</div>
<div class="feature__item ">
    <img src="views/default/img/store-item-6.png" class="feature__img" alt="feature-item">
    <div class="feature__table">
        <table class="table table-feature">
            <tbody><tr class="table__data">
                <td>Имя лесоруба : <span class="table__login">Крис</span></td>
            </tr>
            <tr class="table__data">
                <td>Скорость добычи в месяц :
                    		<span class="table__goods-rub">5 625</span>
					<span class="grey"> (45%)</span>
                </td>
            </tr>
            <tr class="table__data">
              <td>Стоимость :
                    <span class="table__goods-rub">12 500</span>
              </td>
            </tr>
            <tr class="table__data">
              <td>
                <a href="signup" class="input__btn input__btn-about">Нанять</a>
              </td>
            </tr>
        </tbody></table>
    </div>
</div>
<div class="feature__item ">
    <img src="views/default/img/store-item-7.png" class="feature__img" alt="feature-item">
    <div class="feature__table">
        <table class="table table-feature">
            <tbody><tr class="table__data">
                <td>Имя лесоруба : <span class="table__login">Вин</span></td>
            </tr>
            <tr class="table__data">
                <td>Скорость добычи в месяц :
                    		<span class="table__goods-rub">13 750</span>
					<span class="grey"> (55%)</span>
                </td>
            </tr>
            <tr class="table__data">
              <td>Стоимость :
                   <span class="table__goods-rub">25 000</span>
              </td>
            </tr>
            <tr class="table__data">
              <td>
                <a href="signup" class="input__btn input__btn-about">Нанять</a>
              </td>
            </tr>
        </tbody></table>
    </div>
</div>
