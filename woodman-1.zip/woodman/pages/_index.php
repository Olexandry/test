<div class="schema">
  <p class="schema__text">Уникальный проект, где можно легко и просто заработать  кучу денег интересует? Если да, то ты попал по адресу.<br><br>

					Крутые лесорубы с разным уровнем подготовки готовы тебе в этом помочь.<br><br>
					
					Безумный Чико покажет как голыми руками ломать деревья, Крис научит  рубить дрова в мелкие щепки, не успеешь оглянуться, как хитрый Бритт принесет тебе не малый доход. Что же касается Вина и О'Рейли, то эти парни в не конкуренции по выколачиванию денег! И все эти ребята готовы работать на тебя!!!<br><br>

					Волшебный дизайн, надежный и проверенный админ, продуманный маркетинг!!! Что еще нужно чтобы приятно и выгодно проводить время с Woodman?<br><br>

					Да ничего. Пройди простую регистрацию, найми своего лесоруба и начинай набивать карманы!<br><br>

					Да, и еще!!!.. Работяг кормить не нужно. Работают они круглосуточно,а кормят их жены )))<br><br></p>
  <div class="schema__block">
    <div class="schema__headline"><span>Нанять дровосека</span></div>
    <div class="schema__img schema__img-man"></div>
    <a class="input__btn" href="signup">Нанять</a>
  </div>

  <div class="schema__arrows"></div>

  <div class="schema__block">
    <div class="schema__headline"><span class="schema__resource"></span></div>
    <div class="schema__img schema__img-resource"></div>
    <a class="input__btn" href="/signup">Продать</a>
  </div>

  <div class="schema__block schema__block-result">
    <div class="schema__img schema__img-money"></div>
    <a class="input__btn" href="/signup">Вывести</a>
  </div>
</div>       

 
