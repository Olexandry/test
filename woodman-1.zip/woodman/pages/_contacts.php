<?PHP
$_OPTIMIZATION["title"] = "Контакты";
$_OPTIMIZATION["description"] = "Связь с администрацией";
$_OPTIMIZATION["keywords"] = "Связь с администрацией проекта";

    $to = "email@adress.com";
    $subject = "Посылка с контактной формы";
    
    if(isset($_POST["submit"]))  
    {
        if(!preg_match("/^(?:[a-z0-9]+(?:[-_.]?[a-z0-9]+)?@[a-z0-9_.-]
        +(?:.?[a-z0-9]+)?.[a-z]{2,5})$/i",trim($_POST["email"])))
        {
            $message = "<div id='message' class='error'>
            Указанный email не соответствует формату!</div>";
        }
        else
        {
            $message = "<div id='message' class='success'>
            Форма успешно отправленна!</div>";
        }
    }
?>


 <div class="contacts">
	<p class="contacts__text">Возникли проблемы с Брит или не слушается Сотеро? Чико сегодня отказался работать? Кто-то из лесорубов выполнил работу и присвоил себе деньги!? Кальвера вообще куда-то пропал!? Пиши немедленно. Если есть предложения, замечания или пожелания тоже пиши )))</p>


	<div class="contacts__social">
		<div class="contacts__img"></div>

		<ul class="contacts__list">
			<li class="contacts__item"><a href="https://vk.com/" target="_blank"><i class="fa fa-vk"></i></a></li>
			<li class="contacts__item"><a href="https://join.skype.com/логин скайп" target="_blank"><i class="fa fa-skype"></i></a></li>
			<li class="contacts__item"><a href="mailto:ваша почта" target="_blank"><i class="fa fa-envelope"></i></a></li>
		</ul>
	</div>


	<form class="contacts__form" id="contact" method="post">
		<input class="input__text input__text-contacts" name="email" type="text" placeholder="Ваш e-mail" required>
		<input class="input__text input__text-contacts" name="theme" type="text" placeholder="Тема письма" required>
		<textarea class="input__text input__textarea" name="comment" placeholder="Текст сообщения" required></textarea>
		<div id="error_block"></div>
		<input class="input__btn input__btn-contacts" type="submit" name="submit" value="Отправить" >
	</form>



</div>