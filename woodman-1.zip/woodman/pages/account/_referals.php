<?PHP
/* 
Autor: EvgeSH
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$_OPTIMIZATION["title"] = "Аккаунт - Партнерская программа";
$user_id = $_SESSION["user_id"];
$db->Query("SELECT COUNT(*) FROM ".$pref."_users_a WHERE referer_id = '$user_id'");
$refs = $db->FetchRow();
$db->Query("SELECT COUNT(*) FROM ".$pref."_views_reflink WHERE id_ref='$user_id'");
$views=$db->FetchRow();
?>  
<div class="referal">
    <ul class="referal__list">
        <li class="referal__item referal__link">
            Ваша реферальная ссылка:
            <span style="display:inline-block; word-break:break-all;">http://<?=$_SERVER['HTTP_HOST']; ?>/?ref=<?=$_SESSION["user_id"]; ?></span>
        </li>

        <li class="referal__item">
            Переходов по ссылке:
            <span class="referal__follow" id="counter"><?=$views;?> </span>
			        </li>

        <li class="referal__item">
            Реферальный процент:
            <span class="referal__percent">7%</span>
        </li>

        <li class="referal__item">
            Рефералы:
            <span class="referal__sum"><?=$refs; ?></span>
        </li>
        
        <li class="referal__item">
            Доход от рефералов:
          
            <span class="referal__rub">0</span>
        </li>
    </ul>
</div>


