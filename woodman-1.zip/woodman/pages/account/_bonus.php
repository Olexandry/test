<?PHP
/* 
Autor: EvgeSH
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$_OPTIMIZATION["title"] = "Аккаунт - Ежедневный бонус";
$usid = $_SESSION["user_id"];
$uname = $_SESSION["user"];
?>
  <script>
    var isSent = false;
</script>

<div class="bonus">
    <div class="bonus__img" data-scale="100">
        <div class="bonus__scale-wrap">
            <div class="bonus__scale" style="width: 100%;"></div>
        </div>
        <div class="bonus__text">
            <h6>Ежедневный бонус</h6>
                    </div>
    </div>
	<br>
	
<?PHP
$ddel = time() + 60*60*24;
$dadd = time();
$db->Query("SELECT COUNT(*) FROM ".$pref."_bonus_list WHERE user_id = '$usid' AND date_del > '$dadd'");

$hide_form = false;

	if($db->FetchRow() == 0){
	
		# Выдача бонуса
		if(isset($_POST["bonus"])){
		
			$sum = rand($bonus_min, rand($bonus_min, $bonus_max) );
			
			# Зачилсяем юзверю
			$db->Query("UPDATE ".$pref."_users_b SET money_b = money_b + '$sum' WHERE id = '$usid'");
			
			# Вносим запись в список бонусов
			
			
			$db->Query("INSERT INTO ".$pref."_bonus_list (user, user_id, sum, date_add, date_del) VALUES ('$uname','$usid','$sum','$dadd','$ddel')");
			
			# Случайная очистка устаревших записей
			$db->Query("DELETE FROM ".$pref."_bonus_list WHERE date_del < '$dadd'");
			
			echo "
			<div class='bonus__indicator'>
        <div class='bonus__result'>
            <p>
                                   <font color = 'green'><b>Зачислин бонус {$sum} руб.</b></font>                     </p>
        </div>
    </div>
</div>
			
			";
			
			$hide_form = true;
			
		}
			
			# Показывать или нет форму
			if(!$hide_form){
?>


   <form  method="post" >
                         
                           <input type="submit" class="input__btn" name="bonus" style="margin-top:25%;margin-left:-10%" value="Получить бонус">
                            
                   
	
	
    <div class="bonus__indicator">
        <div class="bonus__result">
            <p>
                                    Получи бонус уже сейчас!                            </p>
        </div>
    </div>



  
   </form >



<?PHP 

			}

	}else echo "
	
	 <div class='bonus__indicator'>
        <div class='bonus__result'>
            <p>
                                   <font color = 'red'><b>Вы уже получали бонус </b></font>                     </p>
        </div>
    </div>
</div>
	
	
	
"; ?>

<table class="table table-bonus" id="bonus"><caption class="table__name">Последние 10 бонусов</caption>
    <thead class="table__head">
    <tr>
        <td class="table__head-item">Логин</td>
        <td class="table__head-item">Сумма</td>
        <td class="table__head-item">Дата получения</td>
    </tr>
    </thead>

<tbody>
  <?PHP
  
  $db->Query("SELECT * FROM ".$pref."_bonus_list ORDER BY id DESC LIMIT 20");
  
	if($db->NumRows() > 0){
  
  		while($bon = $db->FetchArray()){
		
		?>
	
	 
            <tr class="table__data">
            <td><?=$bon["user"]; ?></td>
            <td class="table__sum icon__usd"><?=$bon["sum"]; ?></td>
            <td class="table__num"><?=date("d.m.Y",$bon["date_add"]); ?></td>
        </tr>
	
	
	
    		
  
		<?PHP
		
		}
  
	}else echo "<tr><td align='center' colspan='5'>Нет записей</td></tr>"; ?>
</tbody>
</table>
</div>