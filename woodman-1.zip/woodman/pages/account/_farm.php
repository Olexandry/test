<div class="store">

<?PHP
/* 
Autor: EvgeSH
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$_OPTIMIZATION["title"] = "Аккаунт - Ферма";
$usid = $_SESSION["user_id"];
$refid = $_SESSION["referer_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM ".$pref."_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM ".$pref."_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

# Покупка нового дерева
if(isset($_POST["item"])){

$array_items = array(1 => "a_t", 2 => "b_t", 3 => "c_t", 4 => "d_t", 5 => "e_t", 6 => "f_t", 7 => "g_t");
$array_name = array(1 => "Чико", 2 => "Сотеро", 3 => "О'Рейли", 4 => "Бритт", 5 => "Кальвера", 6 => "Крис", 7 => "Вин");
$item = intval($_POST["item"]);
$citem = $array_items[$item];

	if(strlen($citem) >= 3){
		
		# Проверяем средства пользователя
		$need_money = $sonfig_site["amount_".$citem];
		if($need_money <= $user_data["money_b"]){
		
			if($user_data["last_sbor"] == 0 OR $user_data["last_sbor"] > ( time() - 60*20) ){
				
				$to_referer = $need_money * 0.1;
				# Добавляем дерево и списываем деньги
				$db->Query("UPDATE ".$pref."_users_b SET money_b = money_b - $need_money, $citem = $citem + 1,  
				last_sbor = IF(last_sbor > 0, last_sbor, '".time()."') WHERE id = '$usid'");
				
				# Вносим запись о покупке
				$db->Query("INSERT INTO ".$pref."_stats_btree (user_id, user, tree_name, amount, date_add, date_del) 
				VALUES ('$usid','$usname','".$array_name[$item]."','$need_money','".time()."','".(time()+60*60*24*15)."')");
				
				$txt = "Вы наняли {$array_name[$item]} за {$need_money} рублей";
        $db->Query("INSERT INTO ".$pref."_minilogus (user_id, userlog, date_add) VALUES ('$usid', '$txt', '".time()."')");
				
				echo "<center><font color = 'green'><b>Вы успешно наняли дровосека</b></font></center><BR />";
				
				$db->Query("SELECT * FROM ".$pref."_users_b WHERE id = '$usid' LIMIT 1");
				$user_data = $db->FetchArray();
				
			}else echo "<center><font color = 'red'><b>Перед тем как нанять дровосека, следует собрать бревна!</b></font></center><BR />";
		
		}else echo "<center><font color = 'red'><b>Недостаточно денег для найма</b></font></center><BR />";
	
	}else echo 222;

}

?>

 <ul class="store__list store__list-rub" style="display: block;">

                    <li class="store__item">
				<form action="" method="post">
                    <div class="store__name">
                        <span>Чико - </span>
                        <span class="stats__result val__rub"><?=$sonfig_site["amount_a_t"]; ?></span>
                    </div>
                    <div id="error_block_rub1"></div>
                    <div class="store__img"></div>
                    <div class="store__total"><span class="store__ammount">+<?=$sonfig_site["a_in_h"]; ?></span></div>
					<input type="hidden" name="item" value="1" />
                    <input type="submit" class="input__btn" value="Нанять" >
       </form>
		   </li>
		
			
                    <li class="store__item">
					<form action="" method="post">
                    <div class="store__name">
                        <span>Сотеро - </span>
                        <span class="stats__result val__rub"><?=$sonfig_site["amount_b_t"]; ?></span>
                    </div>
                    <div id="error_block_rub2"></div>
                    <div class="store__img"></div>
                    <div class="store__total"><span class="store__ammount">+<?=$sonfig_site["b_in_h"]; ?></span></div>
					<input type="hidden" name="item" value="2" />
                    <input type="submit" class="input__btn" value="Нанять" >
           </form>
		   </li>
		
                    <li class="store__item">
					<form action="" method="post">
                    <div class="store__name">
                        <span>О'Рейли - </span>
                        <span class="stats__result val__rub"><?=$sonfig_site["amount_c_t"]; ?></span>
                    </div>
                    <div id="error_block_rub3"></div>
                    <div class="store__img"></div>
                    <div class="store__total"><span class="store__ammount">+<?=$sonfig_site["c_in_h"]; ?></span></div>
					<input type="hidden" name="item" value="3" />
                    <input type="submit" class="input__btn" value="Нанять" >
            </form>
		   </li>
                    <li class="store__item">
					<form action="" method="post">
                    <div class="store__name">
                        <span>Бритт - </span>
                        <span class="stats__result val__rub"><?=$sonfig_site["amount_d_t"]; ?></span>
                    </div>
                    <div id="error_block_rub4"></div>
                    <div class="store__img"></div>
                    <div class="store__total"><span class="store__ammount">+<?=$sonfig_site["d_in_h"]; ?></span></div>
					<input type="hidden" name="item" value="4" />
                    <input type="submit" class="input__btn" value="Нанять" >
 </form>           
		   </li>
                    <li class="store__item">
					<form action="" method="post">
                    <div class="store__name">
                        <span>Кальвера - </span>
                        <span class="stats__result val__rub"><?=$sonfig_site["amount_e_t"]; ?></span>
                    </div>
                    <div id="error_block_rub5"></div>
                    <div class="store__img"></div>
                    <div class="store__total"><span class="store__ammount">+<?=$sonfig_site["e_in_h"]; ?></span></div>
					<input type="hidden" name="item" value="5" />
                    <input type="submit" class="input__btn" value="Нанять" >
 </form>           
		   </li>
                    <li class="store__item">
					<form action="" method="post">
                    <div class="store__name">
                        <span>Крис - </span>
                        <span class="stats__result val__rub"><?=$sonfig_site["amount_f_t"]; ?></span>
                    </div>
                    <div id="error_block_rub6"></div>
                    <div class="store__img"></div>
                    <div class="store__total"><span class="store__ammount">+<?=$sonfig_site["f_in_h"]; ?></span></div>
					<input type="hidden" name="item" value="6" />
                    <input type="submit" class="input__btn" value="Нанять" >
             </form>
			</li>
                    <li class="store__item">
					<form action="" method="post">
                    <div class="store__name">
                        <span>Вин - </span>
                        <span class="stats__result val__rub"><?=$sonfig_site["amount_g_t"]; ?></span>
                    </div>
                    <div id="error_block_rub7"></div>
                    <div class="store__img"></div>
                    <div class="store__total"><span class="store__ammount">+<?=$sonfig_site["g_in_h"]; ?></span></div>
					<input type="hidden" name="item" value="7" />
                    <input type="submit" class="input__btn" value="Нанять">
            </form>
			</li>
            </ul>
</div>

<div class="divider"></div>

<div id="list"></div> 


