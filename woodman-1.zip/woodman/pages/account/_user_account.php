<?PHP
/* 
Autor: EvgeSH
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$_OPTIMIZATION["title"] = "Аккаунт - Профиль";
$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM ".$pref."_users_a, ".$pref."_users_b WHERE ".$pref."_users_a.id = ".$pref."_users_b.id AND ".$pref."_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>
							
 <div class="profile">
<form action="" method="post">
	<table class="table table-profile">
	  <tbody>
	    <tr class="table__data">
	      <td>Ваш логин</td>
	      <td class="table__sum"><?=$prof_data["user"]; ?></td>
	    </tr>
	    <tr class="table__data">
	      <td>Пополнено</td>
	      <td class="table__sum">
					<span class="table__sum statistics__refill-rub"><?=sprintf("%.2f",$prof_data["insert_sum"]); ?></span>
	    
	      </td>
	    </tr>
	    <tr class="table__data">
	      <td>Выведено</td>
	      <td class="table__sum">
					<span class="table__sum statistics__refill-rub"><?=sprintf("%.2f",$prof_data["payment_sum"]); ?></span>
	     
	      </td>
	    </tr>
	    <tr class="table__data">
	      <td>Реферальный процент</td>
	      <td class="table__sum referal__percent">7</td>
	    </tr>
	    <tr class="table__data">
	      <td>Рефералы</td>
	      <td class="table__sum statistics__register">0 чел</td>
	    </tr>
	    <tr class="table__data">
	      <td>Доход от рефералов</td>
	      <td class="table__sum">
					<span class="table__sum statistics__refill-rub">0</span>
	       
	      </td>
	    </tr>
	    <tr class="table__data">
	      <td>Вас пригласил</td>
	      <td class="table__sum"><?=$prof_data["referer"]; ?></td>
	    </tr>
	    <tr class="table__data">
	      <td>Ваш E-mail</td>
	      <td class="table__sum"><?=$prof_data["email"]; ?></td>
	    </tr>
		
		<tr class="table__data">
		<td>Часовой пояс</td>
               <td> <div class="input__dropdown input__dropdown-timezone">
		  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				
			<button class="input input__dropdown-btn">(UTC  +3:00) Москва, Санкт-Петербург, Волгоград</button>
			<input class="input__hidden" name="timezone" type="text" value="180">
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
				  
								
        <div class="input__dropdown-content">
									
						<a href="/profile" data-key="-720">(UTC  -12:00) Эневеток, Кваджалейн</a>
		  						
						<a href="/profile" data-key="-660">(UTC  -11:00) Остров Мидуэй, Самоа</a>
		  						
						<a href="/profile" data-key="-600">(UTC  -10:00) Гавайи</a>
		  						
						<a href="/profile" data-key="-540">(UTC  -9:00) Аляска</a>
		  						
						<a href="/profile" data-key="-480">(UTC  -8:00) Тихоокеанское время (США и Канада), Тихуана</a>
		  						
						<a href="/profile" data-key="-420">(UTC  -7:00) Горное время (США и Канада), Аризона</a>
		  						
						<a href="/profile" data-key="-360">(UTC  -6:00) Центральное время (США и Канада), Мехико</a>
		  						
						<a href="/profile" data-key="-300">(UTC  -5:00) Восточное время (США и Канада), Богота, Лима</a>
		  						
						<a href="/profile" data-key="-258">(UTC  -4:30) Каракас</a>
		  						
						<a href="/profile" data-key="-240">(UTC  -4:00) Атлантическое время (Канада), Ла Пас</a>
		  						
						<a href="/profile" data-key="-180">(UTC  -3:00) Ньюфаундленд</a>
		  						
						<a href="/profile" data-key="-120">(UTC  -2:00) Бразилия, Буэнос-Айрес, Джорджтаун</a>
		  						
						<a href="/profile" data-key="-60">(UTC  -1:00) Среднеатлантическое время</a>
		  						
						<a href="/profile" data-key="0">(UTC ) Дублин, Лондон, Лиссабон, Касабланка, Эдинбург</a>
		  						
						<a href="/profile" data-key="60">(UTC  +1:00) Брюссель, Копенгаген, Мадрид, Париж, Берлин</a>
		  						
						<a href="/profile" data-key="120">(UTC  +2:00) Афины, Киев, Минск, Бухарест, Рига, Таллин</a>
		  						
						<a href="/profile" data-key="180">(UTC  +3:00) Москва, Санкт-Петербург, Волгоград</a>
		  						
						<a href="/profile" data-key="198">(UTC  +3:30) Тегеран</a>
		  						
						<a href="/profile" data-key="240">(UTC  +4:00) Абу-Даби, Баку, Тбилиси, Ереван</a>
		  						
						<a href="/profile" data-key="258">(UTC  +4:30) Кабул</a>
		  						
						<a href="/profile" data-key="300">(UTC  +5:00) Екатеринбург, Исламабад, Карачи, Ташкент</a>
		  						
						<a href="/profile" data-key="318">(UTC  +5:30) Мумбай, Колката, Ченнаи, Нью-Дели</a>
		  						
						<a href="/profile" data-key="327">(UTC  +5:45) Катманду</a>
		  						
						<a href="/profile" data-key="360">(UTC  +6:00) Омск, Новосибирск, Алма-Ата, Астана</a>
		  						
						<a href="/profile" data-key="378">(UTC  +6:30) Янгон, Кокосовые острова</a>
		  						
						<a href="/profile" data-key="420">(UTC  +7:00) Красноярск, Норильск, Бангкок, Ханой, Джакарта</a>
		  						
						<a href="/profile" data-key="480">(UTC  +8:00) Иркутск, Пекин, Перт, Сингапур, Гонконг</a>
		  						
						<a href="/profile" data-key="540">(UTC  +9:00) Якутск, Токио, Сеул, Осака, Саппоро</a>
		  						
						<a href="/profile" data-key="558">(UTC  +9:30) Аделаида, Дарвин</a>
		  						
						<a href="/profile" data-key="600">(UTC  +10:00) Владивосток, Восточная Австралия, Гуам</a>
		  						
						<a href="/profile" data-key="660">(UTC  +11:00) Магадан, Сахалин, Соломоновы Острова</a>
		  						
						<a href="/profile" data-key="720">(UTC  +12:00) Камчатка, Окленд, Уэллингтон, Фиджи</a>
		          </div>
		
      </div></td>
	  
		</tr>
	    <tr class="table__data">
	      <td>Дата регистрации</td>
	      <td class="table__sum"><?=date("d.m.Y в H:i:s",$prof_data["date_reg"]); ?></td>
	    </tr>
				
		<!--<tr class="table__data">
	      <td>AdvCASH</td>
	      <td class="table__sum"><input class="input__text" type="text" name="advcash" placeholder="Кошелек"></td>	    </tr>
		-->
			<?PHP
	if(isset($_POST["purse"])){
	$purse = $func->ViewPurse($_POST["purse"]);
	$db->Query("SELECT purse FROM ".$pref."_users_a WHERE purse = '$purse'");
	$pr = $db->NumRows();
	
	$db->Query("SELECT purse FROM ".$pref."_users_a WHERE id = '$usid'");
	$prr = $db->FetchArray();
	
		
		
		
			if($purse !== false){
				if($pr == 0) {
					if(empty($prr['purse'])) {
			
					
						$db->Query("UPDATE ".$pref."_users_a SET purse = '$purse' WHERE id = '$usid'");
						
						echo "<center><font color = 'green'><b>Кошелек установлен</b></font></center><BR />";
					
					}else echo "<center><font color = 'red'><b>Вы уже изменяли кошелек!</b></font></center><BR />";
				}else echo "<center><font color = 'red'><b>Данный кошелек уже зарегистрирован</b></font></center><BR />";
			}else echo "<center><font color = 'red'><b>Кошелек имеет не верный формат</b></font></center><BR />";
		
	}
?>



	
		<tr class="table__data">
	      <td>Payeer</td>
	      <td class="table__sum"><input class="input__text" type="text" name="purse" placeholder="Кошелек" value="<?=$user_data['purse']; ?>"></td>	    </tr>
		
			<!--	
		<tr class="table__data">
	      <td>Perfect Money</td>
	      <td class="table__sum"><input class="input__text" type="text" name="pm" placeholder="Кошелек"></td>	    </tr>
		-->
		
		<?PHP
	if(isset($_POST["old"])){
	
		$old = $func->IsPassword($_POST["old"]);
		$new = $func->IsPassword($_POST["new"]);
		
			if($old !== false AND strtolower($old) == strtolower($user_data["pass"])){
			
				if($new !== false){
				
					if( strtolower($new) == strtolower($_POST["re_new"])){
					
						$db->Query("UPDATE ".$pref."_users_a SET pass = '$new' WHERE id = '$usid'");
						
						echo "<center><font color = 'green'><b>Новый пароль успешно установлен</b></font></center><BR />";
					
					}else echo "<center><font color = 'red'><b>Пароль и повтор пароля не совпадают</b></font></center><BR />";
				
				}else echo "<center><font color = 'red'><b>Новый пароль имеет неверный формат</b></font></center><BR />";
			
			}else echo "<center><font color = 'red'><b>Старый паполь заполнен неверно</b></font></center><BR />";
		
	}
?>


		
		
		
				
	    <tr class="table__data">
	      <td>Смена пароля</td>
	      <td>
		  <input class="input__text input__text-pass" name="old" type="password" placeholder="Старый пароль">
	      	<input class="input__text input__text-pass" name="new" type="password" placeholder="Новый пароль">
	      	<input class="input__text" type="password" name="re_new" placeholder="Повторите пароль">
	      </td>
	    </tr>
	  </tbody>
	</table>
	
	<div id="error_block"></div>
	<input class="input__btn" type="button" value="Сохранить" onclick="forms[0].submit();">
	</form>
</div> 
















