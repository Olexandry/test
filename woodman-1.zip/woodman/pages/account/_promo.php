<?
/* 
Autor: EvgeSH
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$_OPTIMIZATION["title"] = "Рекламные материалы";
$usid = $_SESSION["user_id"];
$refid = $_SESSION["referer_id"];
?>  

<div class="promo">
	<span class="promo__size">728х90</span>
	<img src="/views/default/img/promo/728ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="http://<?=$_SERVER['HTTP_HOST']; ?>/views/default/img/promo/728ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="&lt;a href=&quot;https://<?=$_SERVER['HTTP_HOST']; ?>/?ref=<?=$_SESSION["user_id"]; ?>&quot;&gt;http://<?=$_SERVER['HTTP_HOST']; ?>/views/default/img/promo/728ru.gif&lt;/a&gt;">

	<span class="promo__size">468х60</span>
	<img src="/views/default/img/promo/468ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="http://<?=$_SERVER['HTTP_HOST']; ?>/views/default/img/promo/468ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="&lt;a href=&quot;https://<?=$_SERVER['HTTP_HOST']; ?>/?ref=<?=$_SESSION["user_id"]; ?>&quot;&gt;http://<?=$_SERVER['HTTP_HOST']; ?>/views/default/img/promo/468ru.gif&lt;/a&gt;">

	<span class="promo__size">200x300</span>
	<img src="/views/default/img/promo/200ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="http://<?=$_SERVER['HTTP_HOST']; ?>/views/default/img/promo/200ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="&lt;a href=&quot;http://<?=$_SERVER['HTTP_HOST']; ?>/?ref=<?=$_SESSION["user_id"]; ?>&quot;&gt;http://<?=$_SERVER['HTTP_HOST']; ?>/views/default/img/promo/200ru.gif&lt;/a&gt;">
	
	<span class="promo__size">125х125</span>
	<img src="/views/default/img/promo/125ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="http://<?=$_SERVER['HTTP_HOST']; ?>/views/default/img/promo/125ru.gif">
	<input type="text" readonly="" class="input__text input__text-promo" value="&lt;a href=&quot;http://<?=$_SERVER['HTTP_HOST']; ?>/?ref=<?=$_SESSION["user_id"]; ?>&quot;&gt;http://<?=$_SERVER['HTTP_HOST']; ?>z/views/default/img/promo/125ru.gif&lt;/a&gt;">
</div>  
