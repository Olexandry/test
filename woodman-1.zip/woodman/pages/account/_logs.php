<?PHP
/* 
Autor: EvgeSH
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$_OPTIMIZATION["title"] = "��� �������";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM evgesh_users_b WHERE id = '$usid' LIMIT 1");
$user_data = $db->FetchArray();

$db->Query("SELECT * FROM evgesh_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

$db->Query("SELECT COUNT(*) FROM evgesh_minilogus");
$all_logs=$db->FetchRow();

?>


<div class="log">

	      				

<?PHP
if(isset($_GET["p"])) {
$page_now = (intval($_GET['p']))?(intval($_GET['p'])):"1";


$logs = 20;
$pages = ceil($all_logs / $logs);
###
$start = $page_now * $logs - 20;
$stop = ($page_now > 1) ? ($page_now * $logs - 20): $logs;



 $db->Query("SELECT * FROM evgesh_minilogus WHERE user_id = '$usid' ORDER BY id LIMIT $start, $stop");

if($db->NumRows() > 0){
if ($page_now == 0 or $page_now == 1) {
$page_now = 1;
}
echo '<center>';
for($i = 1; $i <= $pages; $i++)
{
echo '   <a href="/?menu=account&sel=logs&p='.$i.'"><font size="3">'.$i.'</font></a>  |';

}echo '</center><br>';


while($data = $db->FetchArray()){

echo "
  <table class='table table-log'>
    <tbody>
 <tr class='table__data'>

  <td>".$data["userlog"]."<span class='table__sum'></span></td>
  
 <td class='table__num table__logtime'>".date("H:i:s d.m.y", $data["date_add"])."</td>

 </tr>
 
 </tbody>
  </table>
 
 ";
}



}



}
else Header("Location: /?menu=account&sel=logs&p");
?>	       


  
</div>
