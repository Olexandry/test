<?PHP
/* 
Autor: EvgeSH
ICQ: 326-728
Email: EvgeSH@ProtonMail.com
*/
$_OPTIMIZATION["title"] = "Аккаунт - Пополнение баланса";
$usid = $_SESSION["user_id"];
$usname = $_SESSION["user"];

$db->Query("SELECT * FROM ".$pref."_config WHERE id = '1' LIMIT 1");
$sonfig_site = $db->FetchArray();

/*
if($_SESSION["user_id"] != 1){
echo "<center><b><font color = red>Технические работы</font></b></center>";
return;
}
*/
?>


        <div class="fill">
            <div class="fill__item-wrap">
                                                     
					
                                                        <div class="fill__item" data-usd="yes" data-rub="yes">
                        <img class="fill__img" src="/views/default/img/payeer.png" alt="payeer">
                        <div class="fill__text"><p>Платежный агрегатор, более 30 различных методов оплаты</p></div>
                        <input type="radio" name="payin" id="payeer" value="payeer">
                    </div>
                                                      
                            </div>


<?
/// db_payeer_insert
if(isset($_POST["sum"])){

$sum = round(floatval($_POST["sum"]),2);


# Заносим в БД
$db->Query("INSERT INTO ".$pref."_payeer_insert (user_id, user, sum, date_add) VALUES ('".$_SESSION["user_id"]."','".$_SESSION["user"]."','$sum','".time()."')");


$txt = "Вы начали операцию пополнения счета на сумму {$sum} руб.";
        $db->Query("INSERT INTO ".$pref."_minilogus (user_id, userlog, date_add) VALUES ('$usid', '$txt', '".time()."')");

$desc = base64_encode($_SERVER["HTTP_HOST"]." - USER ".$_SESSION["user"]);
$m_shop = $config->shopID;
$m_orderid = $db->LastInsert();
$m_amount = number_format($sum, 2, ".", "");
$m_curr = "RUB";
$m_desc = $desc;
$m_key = $config->secretW;

$arHash = array(
 $m_shop,
 $m_orderid,
 $m_amount,
 $m_curr,
 $m_desc,
 $m_key
);
$sign = strtoupper(hash('sha256', implode(":", $arHash)));

?>
<center>

<form method="GET" id="myform" action="//payeer.com/api/merchant/m.php">
	<input type="hidden" name="m_shop" value="<?=$config->shopID; ?>">
	<input type="hidden" name="m_orderid" value="<?=$m_orderid; ?>">
	<input type="hidden" name="m_amount" value="<?=number_format($sum, 2, ".", "")?>">
	<input type="hidden" name="m_curr" value="RUB">
	<input type="hidden" name="m_desc" value="<?=$desc; ?>">
	<input type="hidden" name="m_sign" value="<?=$sign; ?>">
	<input type="submit" name="m_process"  />
</form>
</center>

<script type="text/javascript">

 setTimeout(function(){document.getElementById('myform').submit()},1)

</script>


<div class="clr"></div>		
</div>
<?PHP

return;
}
?>
<script type="text/javascript">
var min = 0.01;
var ser_pr = 100;
function calculate(st_q) {
    
	var sum_insert = parseFloat(st_q);
	$('#res_sum').html( (sum_insert * ser_pr).toFixed(0) );
	
	
}
	
</script>



<form method="POST" action="">
 <input type="hidden" name="m" value="<?=$fk_merchant_id?>">


            <div class="fill__inputs">
                <div class="input__dropdown input__dropdown-fill">
                    <button class="input input__dropdown-btn">RUB</button>
                    <input class="input__hidden" type="text" name="valute" value="usd">
                  
                </div>
                
                <input class="input__text input__text-fill" name="sum" type="text"  placeholder="Введите сумму" onchange="calculate(this.value)" onkeyup="calculate(this.value)" onfocusout="calculate(this.value)" onactivate="calculate(this.value)" ondeactivate="calculate(this.value)">
                <input class="input__btn" type="submit" value="Пополнить">
            </div>
        </div>
    </form>
	<script type="text/javascript">
calculate(100);
</script>
    <div id="error_block"></div>

<div id="pay_block">﻿
  


</div>







