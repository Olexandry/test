<?PHP
$_OPTIMIZATION["title"] = "Последние выплаты";
$_OPTIMIZATION["description"] = "Список последних выплат";
$_OPTIMIZATION["keywords"] = "Последние выплаты";
?>

 <div class="statistics">
  <ul class="statistics__list">
    <li class="statistics__item">
      Пополнения(за последние 48 часов)
      
    
	  <span class="statistics__refill-rub"></span>
      <input class="input__btn input__btn-stats" type="button" value="Подробнее">

      <div class="table__wrap">
	  
	   <?PHP

$dt = time() - 60*60*48;

$db->Query("SELECT * FROM ".$pref."_payeer_insert WHERE status = '1' AND date_add > '$dt'");



if($db->NumRows() > 0){

$all_pay = 0;
$all_pay_sum = 0;

?>
	  
	           <table class="table table-statistics">
          <thead class="table__head">
            <tr>
              <td class="table__head-item">Логин</td>
              <td class="table__head-item">Сумма</td>
              <td class="table__head-item">Платежная система</td>
              <td class="table__head-item">Дата пополнения</td>
            </tr>
          </thead>
		  
		  <?PHP

	while($data = $db->FetchArray()){
	$all_pay ++;
	$all_pay_sum += $data["sum"];
	?>
		  
		  
          <tbody>

		              <tr class="table__data">
              <td><?=$data["user"]; ?></td>
              <td class="table__sum">
			                  <span class="table__goods-rub"><?=sprintf("%.2f",$data["sum"]); ?></span>
			                </td>
              <td>Payeer</td>
              <td class="table__num"><?=date("d.m.Y H:i:s",$data["date_add"]); ?></td>
            </tr>
			           
			          </tbody>
					  
					  
					  
					  
					  
                    </table>
					
						<?PHP
	
	}

?>

<?PHP


}else echo "<center><b>Пополнений нет :(</b></center><BR />";


?>
					
					
      </div>
    </li>
	
    <li class="statistics__item">
      Выплаты(за последние 48 часов)
    
	  <span class="statistics__pay-rub"></span>
      <input class="input__btn input__btn-stats" type="button" value="Подробнее">
  <div class="table__wrap">
 
	  <?PHP

$dt = time() - 60*60*48;

$db->Query("SELECT * FROM ".$pref."_payment WHERE status = '3' AND date_add > '$dt'");



if($db->NumRows() > 0){

$all_pay = 0;
$all_pay_sum = 0;

?>

                   <table class="table table-statistics">
          <thead class="table__head">
            <tr>
              <td class="table__head-item">Логин</td>
              <td class="table__head-item">Сумма</td>
              <td class="table__head-item">Платежная система</td>
              <td class="table__head-item">Дата выплаты</td>
            </tr>
          </thead>

<?PHP

	while($data = $db->FetchArray()){
	$all_pay ++;
	$all_pay_sum += $data["sum"];
	?>
	
	 <tbody>

		              <tr class="table__data">
              <td><?=$data["user"]; ?></td>
              <td class="table__sum">
			                  <span class="table__goods-rub"><?=sprintf("%.2f",$data["sum"]); ?></span>
			                </td>
              <td>Payeer</td>
              <td class="table__num"><?=date("d.m.Y H:i:s",$data["date_add"]); ?></td>
            </tr>
		              
		                      </tbody>
	 </table>

	<?PHP
	
	}

?>

<?PHP


}else echo "<center><b>Выплат нет :(</b></center><BR />";


?>
	   
	</div>  

    </li>
    
	
	<li class="statistics__item">
      <span class="statistics__top-refill-rub">Топ 100 пополнений</span>
      <input class="input__btn input__btn-stats" type="button" value="Подробнее">
      
	  <div class="table__wrap">
	 
	    
  <?PHP

  $db->Query("SELECT * FROM evgesh_insert_money ORDER BY id DESC LIMIT 100");

  if($db->NumRows() > 0){

      while($data = $db->FetchArray()){

    ?>
	
	<table class="table table-statistics">
          <thead class="table__head">
            <tr>
              <td class="table__head-item">Логин</td>
              <td class="table__head-item">Сумма</td>
             <td class="table__head-item">Платежная система</td>
            </tr>
          </thead>
	


	
	<tbody>
		              <tr class="table__data">
              <td><?=$data["user"]; ?></td>
              <td class="table__sum table__goods-rub"><?=$data["money"]; ?></td>
              <td >Payeer</td>
			
            </tr>
			           
				    </tbody>
	   
	
	   </table>
  
    <?PHP

    }

  }else echo '<center><b>Нет пополнений :(</b></center><BR />'
  ?>
	  
	
	  
	  
	  </div>
	</li>
	  
	  
	  
      

	
    <li class="statistics__item">
      <span class="statistics__top-pay-rub">Топ 100 выплат</span>
      <input class="input__btn input__btn-stats" type="button" value="Подробнее">

      <div class="table__wrap">
	  
                  <table class="table table-statistics">
	   <?PHP

  $db->Query("SELECT * FROM evgesh_insert_money ORDER BY id DESC LIMIT 100");

  if($db->NumRows() > 0){

      while($data = $db->FetchArray()){

    ?>
   
   
	  
          <thead class="table__head">
            <tr>
              <td class="table__head-item">Логин</td>
              <td class="table__head-item">Сумма</td>
              <td class="table__head-item">Платежная система</td>
            </tr>
          </thead>
          <tbody>
		              <tr class="table__data">
              <td><?=$data["user"]; ?></td>
              <td class="table__sum table__goods-rub"><?=$data["money"]; ?></td>
              <td >Payeer</td>
            </tr>
		          
		          </tbody>
     
		 <?PHP

    }

  }else echo '<center><b>Нет выплат :(</b></center><BR />'
  ?>   </table>
               </div>
    </li>
    <?PHP

$user_id = $_SESSION["user_id"];
$db->Query("SELECT * FROM evgesh_users_a, evgesh_users_b WHERE evgesh_users_a.id = evgesh_users_b.id AND evgesh_users_a.id = '$user_id'");
$prof_data = $db->FetchArray();
?>

    <li class="statistics__item">
      <span class="statistics__refold">Топ 100 рефоводов</span>
      <input class="input__btn input__btn-stats" type="button" value="Подробнее">
      
      <div class="table__wrap">
	   <table class="table table-statistics">
	  <?PHP

$num_p = (isset($_GET["page"]) AND intval($_GET["page"]) < 1000 AND intval($_GET["page"]) >= 1) ? (intval($_GET["page"]) -1) : 0;
$lim = $num_p * 100;

$db->Query("SELECT * FROM evgesh_users_a ORDER BY referals DESC LIMIT 100");

if($db->NumRows() > 0){

?>
	  
                 
          <thead class="table__head">
            <tr>
              <td class="table__head-item">Логин</td>
              <td class="table__head-item">Рефералов</td>
              <td class="table__head-item">Дата регистрации</td>
            </tr>
          </thead>
		  
		  <?PHP
$i = 0;
	while($data = $db->FetchArray()){
	$i=$i+1;


	?>
		  
          <tbody>
		               <tr class="table__data">
              <td><?=$data["user"]; ?></td>
              <td class="table__sum"><?=$data["referals"]; ?></td>
              <td class="table__num"><?=date("d.m.Y в H:i:s",$prof_data["date_reg"]); ?></td>
            </tr>
		               
		             </tbody>
     
		
<?PHP
	}?>	
 </table>
<?PHP
}
		?>	
              </div>
    </li>
    </ul>
</div> 


















