<?PHP
######################################
# Скрипт Fruit Farm
# Автор Rufus
# ICQ: 819-374
# Skype: Rufus272
######################################
$_OPTIMIZATION["title"] = "Новости";
$_OPTIMIZATION["description"] = "Новости проекта";
$_OPTIMIZATION["keywords"] = "Новости нашего проекта";
?>
<div class="news">
	<div class="news__item">
		

<?PHP

$db->Query("SELECT * FROM ".$pref."_news ORDER BY id DESC");

if($db->NumRows() > 0){

	while($news = $db->FetchArray()){
	
	?>

    <div class="news__headline">
			<h5 class="news__name"><?=$func->Base64de($news["title"]); ?></h5>
			<span class="news__date"><?=date("d.m.Y", $news["date_add"]); ?></span>
		</div>        

		
		<p class="news__text">
		
   <?=$func->Base64de($news["news"]); ?>
  
  </p>
	

	<?PHP
	
	}

}else echo "<center>Новостей нет :(</center>";

?>
</div>

</div>        